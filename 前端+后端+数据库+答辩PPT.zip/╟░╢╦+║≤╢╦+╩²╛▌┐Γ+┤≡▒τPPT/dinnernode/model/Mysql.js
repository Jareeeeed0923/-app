var mysql = require('mysql');
var conn = null;

function connect() {
	conn = mysql.createConnection({
		host: 'localhost',
		port: 3306,
		user: 'root',
		password: '1009', // Mysql密码
		database: 'dinner', // 数据库名字
	});
	conn.connect(error);
	conn.on('error', error);
}

function error(err) {
	if (err) {
		if (err.code = 'PROTOCOL_CONNECTION_LOST') {
			connect();
		} else {
			console.error(err.stack || err);
		}
	}
}

mysql.sql = (sql, callback, params) => {
	conn.query(sql, params, (err, rows) => {
		if (err) console.log(err);
		callback(rows);
	});
}

connect();

module.exports = mysql;