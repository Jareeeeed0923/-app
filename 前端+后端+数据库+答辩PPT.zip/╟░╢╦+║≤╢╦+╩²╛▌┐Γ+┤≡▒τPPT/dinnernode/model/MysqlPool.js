var mysql = require('mysql2');

conn = mysql.createPool({ // 数据库连接池
	host: 'localhost',
	port: 3306,
	user: 'root',
	password: '1009', // Mysql密码
	database: 'dinner', // 数据库名字
});

mysql.sql = (sql, callback, params) => {
	conn.query(sql, params, (err, rows) => {
		if (err) console.log(err);
		callback(rows);
	});
}

module.exports = mysql;