var moment = require('moment');
module.exports = function (data, column) {
  if (data) {
	if (!column) {
		column = 'ctime';
	}
	for (var item of data) {
		item[column] = moment(item[column]).format('yyyy-MM-DD HH:mm');
	}
  }
  return data;
}