var express = require('express');
var router = express.Router();
//require导入db数据库
var db = require('../model/MysqlPool.js')

router.get('/coupon/getNumById/app', (req, resp)=> {
	var uid = req.query.uid; 
	db.sql('select count(*) as x from tbl_coupon where uid = ? and useful = 1', data=> {
		resp.json({
			tot: data
		});
	}, [uid]);
});

router.get('/coupon/getByUid/app', (req, resp)=> {
	var uid = req.query.uid; 
	db.sql('select * from tbl_coupon where uid = ? and useful = 1', data=> {
		resp.json({
			coupon: data
		});
	}, [uid]);
});

router.get('/coupon/getByid/app', (req, resp)=> {
	var id = req.query.id; 
	db.sql('select * from tbl_coupon where id = ?', data=> {
		resp.json({
			coupon: data
		});
	}, [id]);
});

router.get('/coupon/useCoupon/app', (req, resp)=> {
	var id = req.query.id; 
	db.sql('update tbl_coupon set useful = 0 where id = ?', data=> {
		resp.json(1);
	}, [id]);
});

router.get('/coupon/addCoupon/app', (req, resp)=> {
	var name = req.query.name;
	var value = req.query.value;
	var uid = req.query.uid;
	var useful = req.query.useful
	db.sql('insert into tbl_coupon(uid, name, value, useful) values(?, ?, ?, ?) ', data=> {
		resp.json(1);
	}, [uid, name, value, useful]);
});

router.get('/coupon/gotCoupon/app', (req, resp)=> {
	var id = req.query.uid; 
	db.sql('insert into tbl_gotcoupon(uid, cangot) values(?, 1) ', data=> {
		resp.json(1);
	}, [id]);
});
 
module.exports = router;