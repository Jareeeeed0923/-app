var express = require('express');
// const req = require('express/lib/request');
var router = express.Router();
var db = require('../model/MysqlPool.js');

router.get('/food/menu/app', (req, resp)=> {
	var cid = req.query.cid; //按类别id查询有哪些菜品
	db.sql('select * from v_food where cid = ?', data=> {
		resp.json({
			foods: data
		});
	}, [cid]);
});

router.get('/food/index/app', (req, resp)=> {
	db.sql('select * from tbl_category', categorys=> {
		db.sql('select logo from tbl_food where hot = "热卖" ', hots=> {
			
			for(var i in hots) {
				hots[i] = hots[i].logo;
			}
			
			var cid = categorys.length > 0 ? categorys[0].id : 0;
			db.sql('select * from v_food where cid = ?', foods => {
				
				resp.json({
					'categorys' : categorys,
					'foods' : foods,
					'hots' : hots
				});
			}, [cid]);
		});
	});
})

//拼接关系
//必须返回 种格式才能。
router.get('/food/cid', (req, resp) => {
	db.sql('select * from tbl_category', data=> {
		var cidValue = [];
		for (var item of data) {
			cidValue.push({
				value: item.id,
				label: item.category,
			});
		}
		resp.json({
			cid: cidValue,
			hot: [
				{
					label: '热卖',
					value: '热卖'
				},
				{
					label: '非热卖',
					value: '非热卖'
				}
			]
		})
	}, [req.params]);
});

router.get('/food', (req, resp)=> {
	db.sql('select * from v_food', data=> {
		resp.json(data);
	});
});

router.get('/food/:id', (req, resp)=> {
	db.sql('delete from tbl_food where id=?', data=> {
		resp.json(1);
	}, [req.params.id]);
});

//添加和修改post
router.post('/food', (req, resp) => {
	controller(req, resp);
});
router.post('/food/:id', (req, resp) => {
	controller(req, resp);
});
function controller(req, resp) {
	var id = req.params.id;
	var food = req.body.food;
	var price = req.body.price;
	var cid = req.body.cid;
	var logo = req.body.logo;
	var hot = req.body.hot;
	if(!food || !price || !logo) {
		resp.json('请完善信息');
		return;
	}
	var sql = '';
	if(id) {
		sql = 'update tbl_food set food=?, price=?, cid=?, logo=?, hot=? where id= ?';
	}
	else {
		sql = 'insert into tbl_food(food, price, cid, logo, hot) values(?, ?, ?, ?, ?)';
	}
	db.sql(sql, data=> {
		resp.json(1);
	}, [
		food, price, cid, logo, hot, id
	]);
}

module.exports = router;
