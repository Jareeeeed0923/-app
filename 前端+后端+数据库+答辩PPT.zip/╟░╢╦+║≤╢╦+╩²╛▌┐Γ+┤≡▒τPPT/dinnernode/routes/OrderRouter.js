var express = require('express');
var router = express.Router(); 
var db = require('../model/MysqlPool.js');
var formatDate = require('../model/FormatDate.js')

// 鸿蒙的预览器暂时不支持post提交
// 手机的get()使用的是?传参
router.get('/order/add/app', (req, resp)=> {
		var fid = req.query.fid;
		var uid = req.query.uid;
		var count = req.query.count;
		var phone = req.query.phone;
		var address = req.query.address;
		
		if(!count || !address || !phone) {
			resp.json('请完善信息');
			return;
		}
		
		db.sql('insert into tbl_order(uid, fid, count, address, phone, ctime) values(?, ?, ?, ?, ?, now())', data=> {
			resp.json(1);
		}, [uid, fid, count, address, phone]);
});

//查询视图
router.get('/vorder/ask/app', (req, resp) => {
	db.sql('select * from v_order order by id desc', data => {
		resp.json(formatDate(data));
	});
});


router.get('/vorder/askById/app', (req, resp)=> {
	var id = req.query.id; //按类别id查询有哪些菜品
	db.sql('select * from v_order where id = ?', data=> {
		resp.json({
			vorder: formatDate(data)
		});
	}, [id]);
});

router.get('/order/askById/app', (req, resp)=> {
	var id = req.query.id; //按类别id查询有哪些菜品
	db.sql('select * from tbl_order where id = ?', data=> {
		resp.json({
			order: formatDate(data)
		});
	}, [id]);
});

//查询视图
router.get('/order', (req, resp) => {
	db.sql('select * from v_order order by id desc', data => {
		resp.json(formatDate(data));
	});
});

module.exports = router;