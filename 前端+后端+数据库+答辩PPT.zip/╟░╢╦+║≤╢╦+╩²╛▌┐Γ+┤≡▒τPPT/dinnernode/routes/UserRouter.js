var express = require('express');
var router = express.Router(); //导入router路由

var db = require('../model/MysqlPool.js');

router.get('/user/addPoint/app', (req, resp)=> {
	var id = req.query.uid; 
	var value = req.query.value
	db.sql('update tbl_user set point = point + ? where id = ?', data=> {
		resp.json(1);
	}, [value, id]);
});

router.get('/user/subPoint/app', (req, resp)=> {
	var id = req.query.uid; 
	var value = req.query.value
	db.sql('update tbl_user set point = point - ? where id = ?', data=> {
		resp.json(1);
	}, [value, id]);
});

router.get('/user/askById/app', (req, resp)=> {
	var id = req.query.id; //按类别id查询有哪些菜品
	db.sql('select * from tbl_user where id = ?', data=> {
		resp.json({
			user: data
		});
	}, [id]);
});	


//开放一个/ellogin地址
//req请求对象，
//resp响应对象，
router.get('/ellogin', (req, resp)=>{
	var username = req.query.username;
	var password = req.query.password;
	db.sql('select * from tbl_user where username=? and password=?', data=>{
		//给网页返回json数据		
		resp.json({ //使用js对象来组织json数据
			code: data.length,
			uid: data.length != 0 ? data[0].id : '',
			user: data.length != 0 ? data[0].username : '',
			status: '管理员',
		});
		
	}, [username, password]);
});



module.exports = router;
