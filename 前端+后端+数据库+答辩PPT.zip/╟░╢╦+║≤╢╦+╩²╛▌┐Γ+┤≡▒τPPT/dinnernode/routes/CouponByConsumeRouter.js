var express = require('express');
var router = express.Router();
//require导入db数据库
var db = require('../model/MysqlPool.js')

router.get('/numByConsume/getByuid/app', (req, resp)=> {
	var uid = req.query.uid; 
	db.sql('select count(*) from tbl_gotcoupon where uid = ?', data=> {
		resp.json({
			num: data
		});
	}, [uid]);
});

router.get('/couponByConsume/getByuid/app', (req, resp)=> {
	var uid = req.query.uid; 
	db.sql('select * from tbl_gotcoupon where uid = ?', data=> {
		resp.json({
			gotCoupon: data
		});
	}, [uid]);
});

router.get('/couponByConsume/deleteByid/app', (req, resp)=> {
	var id = req.query.id; 
	db.sql('delete from tbl_gotcoupon where id = ?', data=> {
		resp.json(1);
	}, [id]);
});


 
module.exports = router;