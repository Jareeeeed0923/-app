var express = require('express');
var router = express.Router();

var db = require('../model/MysqlPool.js');

router.get('/user/askById/app', (req, resp)=> {
	var id = req.query.id; //按类别id查询有哪些菜品
	db.sql('select * from tbl_user where id = ?', data=> {
		resp.json({
			user: data
		});
	}, [id]);
});

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});



module.exports = router;
