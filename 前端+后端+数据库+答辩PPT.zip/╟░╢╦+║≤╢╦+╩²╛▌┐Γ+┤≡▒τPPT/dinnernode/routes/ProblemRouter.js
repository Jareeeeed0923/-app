var express = require('express');
var router = express.Router(); 
var db = require('../model/MysqlPool.js');

router.get('/problem/add/app', (req, resp)=> {
	var phone = req.query.phone;
	var detail = req.query.detail;
	db.sql('insert into tbl_problem(phone, detail) values(?, ?)', data=> {
		resp.json(1);
	}, [phone, detail]);
});

module.exports = router;