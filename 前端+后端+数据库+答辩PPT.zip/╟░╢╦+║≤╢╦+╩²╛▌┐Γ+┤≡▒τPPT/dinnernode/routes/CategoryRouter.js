var express = require('express');
var router = express.Router();
//require导入db数据库
var db = require('../model/MysqlPool.js')

router.get('/category', (req,resp)=> {
	db.sql('select * from tbl_category order by id asc', data=>{
		resp.json(data);
	});
});

//如果地址 /category/数字 req.params.id取参数
//如果地址 /category?id=数字 req.query.id取参数

//删除
router.get('/category/:id', (req, resp) =>{
	var id = req.params.id;
	db.sql('delete from tbl_category where id = ?', data=>{
		resp.json(1); //操作成功，网页看到就会立即刷新
	}, [id]);
});

// 查询和删除都是 get请求
// 添加和修改都是 post请求

//把添加和修改一起写

// 添加
router.post('/category', (req, resp)=> {
	controller(req, resp);
});

// 修改
router.post('/category/:id', (req, resp)=> {
	controller(req, resp);
});
// 在Router中可以定义函数
function controller(req, resp) {
	var id = req.params.id;	// <form> 通过fetch post提交参数，参数放到了body里
	var category = req.body.category; // post除id之外都用body获取参数
	if(!category) {
		resp.json('请完善信息');
		return;
	}
	var sql = 'select * from tbl_category where category = ?';
	if(id) {
		sql+= ' and id != ?';
	}
	db.sql(sql, data=> {
		if(data.length) {
			resp.json(category + '已经存在了');
		}
		else {
			service(req, resp, category, id);
		}
	}, [category, id]);
	
}

function service(req, resp, category, id) {
	// sql
	var sql = '';
	if(id) { // 如果传入主键id
		sql = 'update tbl_category set category = ? where id = ?';
	}
	else {
		sql = 'insert into tbl_category(category) values(?)';
	}
	// 执行sql
	db.sql(sql, data=> { // sql执行成功的回调函数
		resp.json(1); //告诉网页操作成功
	}, [category, id]);
}


module.exports = router;
