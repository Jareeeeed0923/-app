var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

//1. require导入userRouter
var couponRouter = require('./routes/CouponRouter.js')
var orderRouter = require('./routes/OrderRouter.js')
var foodRouter = require('./routes/FoodRouter.js')
var categoryRouter = require('./routes/CategoryRouter.js')
var userRouter = require('./routes/UserRouter.js')
var couponByConsumeRouter = require('./routes/CouponByConsumeRouter.js')
var problemRouter = require('./routes/ProblemRouter.js')

var parser = require('body-parser'); //导入parser
var cors = require('cors');
const req = require('express/lib/request');
var app = express();
app.use(cors()); // 解决跨域问题，想让9948访问到3000需要解决跨域问题
app.use(parser.json({limit:'500kb'})); //设置图片上传容量

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

//2. 注册
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use(foodRouter);
app.use(userRouter);
app.use(categoryRouter);
app.use(orderRouter);
app.use(couponRouter);
app.use(couponByConsumeRouter);
app.use(problemRouter);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
