export const NavigationList = [
    {
        icon_normal: { "id": 16777246, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        icon_selected: { "id": 16777253, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        text: "首页",
        id: 0
    },
    {
        icon_normal: { "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        icon_selected: { "id": 16777254, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        text: "点单",
        id: 1
    },
    {
        icon_normal: { "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        icon_selected: { "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        text: "订单",
        id: 2
    },
    {
        icon_normal: { "id": 16777260, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        icon_selected: { "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
        text: "我的",
        id: 3
    },
];
//# sourceMappingURL=NavigationList.js.map