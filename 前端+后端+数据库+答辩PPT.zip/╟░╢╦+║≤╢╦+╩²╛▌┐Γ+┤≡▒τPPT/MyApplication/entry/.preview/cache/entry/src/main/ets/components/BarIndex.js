import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { User } from '@bundle:com.example.myapplication/entry/ets/model/Bean';
import router from '@ohos:router';
import { TitleBarNoBack } from '@bundle:com.example.myapplication/entry/ets/components/TitileBarNoBack';
export class BarIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__hots = new ObservedPropertyObjectPU(['https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%B8%80%E5%85%83%E5%BC%80%E6%8A%A2.jpg', 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E9%B1%BC.jpg'], this, "hots");
        this.__uid = new ObservedPropertySimplePU(0, this, "uid");
        this.__user = new ObservedPropertyObjectPU(new User(), this, "user");
        this.__point = new ObservedPropertySimplePU(0, this, "point");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__totOfCoupon = new ObservedPropertySimplePU(0, this, "totOfCoupon");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.hots !== undefined) {
            this.hots = params.hots;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
        if (params.user !== undefined) {
            this.user = params.user;
        }
        if (params.point !== undefined) {
            this.point = params.point;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.totOfCoupon !== undefined) {
            this.totOfCoupon = params.totOfCoupon;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__hots.purgeDependencyOnElmtId(rmElmtId);
        this.__uid.purgeDependencyOnElmtId(rmElmtId);
        this.__user.purgeDependencyOnElmtId(rmElmtId);
        this.__point.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__totOfCoupon.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__hots.aboutToBeDeleted();
        this.__uid.aboutToBeDeleted();
        this.__user.aboutToBeDeleted();
        this.__point.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__totOfCoupon.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get hots() {
        return this.__hots.get();
    }
    set hots(newValue) {
        this.__hots.set(newValue);
    }
    get uid() {
        return this.__uid.get();
    }
    set uid(newValue) {
        this.__uid.set(newValue);
    }
    get user() {
        return this.__user.get();
    }
    set user(newValue) {
        this.__user.set(newValue);
    }
    get point() {
        return this.__point.get();
    }
    set point(newValue) {
        this.__point.set(newValue);
    }
    get username() {
        return this.__username.get();
    }
    set username(newValue) {
        this.__username.set(newValue);
    }
    get totOfCoupon() {
        return this.__totOfCoupon.get();
    }
    set totOfCoupon(newValue) {
        this.__totOfCoupon.set(newValue);
    }
    aboutToAppear() {
        this.uid = parseInt(router.getParams()['uid']);
        this.getUser();
        this.getNumOfCoupon();
    }
    getUser() {
        let http = new Http('/user/askById/app?id=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.user = resp.user[0];
            this.point = this.user.point;
            this.username = this.user.username;
        });
    }
    getNumOfCoupon() {
        let http = new Http('/coupon/getNumById/app?uid=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.totOfCoupon = resp.tot[0].x;
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarIndex.ets(50:5)");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#EEEEEF');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBarNoBack(this, { title: '首页' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("components/BarIndex.ets(53:7)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //swiper
            if (this.hots.length) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Swiper.create();
                        Swiper.debugLine("components/BarIndex.ets(56:11)");
                        Swiper.autoPlay(true);
                        Swiper.interval(3000);
                        Swiper.duration(1000);
                        Swiper.width('100%');
                        Swiper.height(200);
                        Swiper.margin({ bottom: 40 });
                        if (!isInitialRender) {
                            Swiper.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Image.create(item);
                                Image.debugLine("components/BarIndex.ets(58:15)");
                                Image.width('100%');
                                Image.height(100);
                                if (!isInitialRender) {
                                    Image.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        };
                        this.forEachUpdateFunction(elmtId, this.hots, forEachItemGenFunction);
                        if (!isInitialRender) {
                            ForEach.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    ForEach.pop();
                    Swiper.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarIndex.ets(70:9)");
            Column.width("90%");
            Column.height(80);
            Column.margin({ top: 160 });
            Column.borderRadius(10);
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarIndex.ets(71:11)");
            Row.margin({ top: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83.png');
            Image.debugLine("components/BarIndex.ets(72:13)");
            Image.width(40);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarIndex.ets(75:13)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.username);
            Text.debugLine("components/BarIndex.ets(76:15)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("可享【新品试吃】等12项权限");
            Text.debugLine("components/BarIndex.ets(78:15)");
            Text.fontColor(Color.Gray);
            Text.fontSize(10);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarIndex.ets(84:13)");
            Column.margin({ left: 12 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.point.toString());
            Text.debugLine("components/BarIndex.ets(85:15)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("会员积分");
            Text.debugLine("components/BarIndex.ets(87:15)");
            Text.fontColor(Color.Gray);
            Text.fontSize(12);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarIndex.ets(91:13)");
            Column.margin({ left: 8 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.totOfCoupon.toString());
            Text.debugLine("components/BarIndex.ets(92:15)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("优惠券");
            Text.debugLine("components/BarIndex.ets(94:15)");
            Text.fontColor(Color.Gray);
            Text.fontSize(12);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
        Column.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarIndex.ets(106:7)");
            Column.width('90%');
            Column.height(400);
            Column.margin({ top: 12 });
            Column.borderRadius(10);
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("大家都在吃");
            Text.debugLine("components/BarIndex.ets(107:9)");
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: -150, top: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/food1.jpg');
            Image.debugLine("components/BarIndex.ets(110:9)");
            Image.width('90%');
            Image.height(160);
            Image.borderRadius(10);
            Image.margin({ top: 14 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/food3.jpg');
            Image.debugLine("components/BarIndex.ets(115:9)");
            Image.width('90%');
            Image.borderRadius(10);
            Image.height(160);
            Image.margin({ top: 18 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "BarIndex", new BarIndex(undefined, {}));
}
//# sourceMappingURL=BarIndex.js.map