import router from '@ohos:router';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import { User } from '@bundle:com.example.myapplication/entry/ets/model/Bean';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { Util } from '@bundle:com.example.myapplication/entry/ets/model/Util';
class PointCenter extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__point = new ObservedPropertySimplePU(0, this, "point");
        this.user = new User();
        this.uid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.point !== undefined) {
            this.point = params.point;
        }
        if (params.user !== undefined) {
            this.user = params.user;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__point.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__point.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get point() {
        return this.__point.get();
    }
    set point(newValue) {
        this.__point.set(newValue);
    }
    aboutToAppear() {
        this.uid = router.getParams()['uid'];
        this.getPoint();
    }
    getPoint() {
        let http = new Http('/user/askById/app?id=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.user = resp.user[0];
            this.point = this.user.point;
        });
    }
    addCoupon(value) {
        let name = value.toString() + "元优惠券";
        let http = new Http('/coupon/addCoupon/app');
        http.get({
            uid: this.uid,
            value: value,
            name: name,
            useful: 1
        }).then((resp) => {
            resp = http.parse(resp);
            if (resp == 1) {
                Util.alert('兑换成功');
            }
            else {
                Util.alert(resp);
            }
        });
    }
    subPoint(value) {
        let http = new Http('/user/subPoint/app');
        http.get({
            uid: this.uid,
            value: value,
        }).then((resp) => {
            resp = http.parse(resp);
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(65:5)");
            Column.backgroundColor('#007DFE');
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: "积分中心" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(68:7)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: -140, top: 40 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(69:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E9%87%91%E5%B8%81.png');
            Image.debugLine("pages/PointCenter.ets(70:11)");
            Image.width(50);
            Image.margin({ right: 6 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.point.toString());
            Text.debugLine("pages/PointCenter.ets(73:11)");
            Text.fontSize(50);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("收集金币，兑换好礼");
            Text.debugLine("pages/PointCenter.ets(78:9)");
            Text.fontColor(Color.White);
            Text.margin({ top: 5 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(85:7)");
            Column.margin({ top: 40 });
            Column.backgroundColor('#EEEEEF');
            Column.height('100%');
            Column.width("100%");
            Column.borderRadius(20);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("热门兑换");
            Text.debugLine("pages/PointCenter.ets(86:9)");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: -160, top: 20 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(91:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(92:11)");
            Column.margin({ top: 20, right: 16 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
            Image.debugLine("pages/PointCenter.ets(93:13)");
            Image.width(160);
            Image.padding({ left: 20, right: 20 });
            Image.backgroundColor('#ffaedfee');
            Image.borderRadius({ topLeft: 10, topRight: 10 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(99:13)");
            Row.height(50);
            Row.width(160);
            Row.backgroundColor(Color.White);
            Row.borderRadius({ bottomLeft: 10, bottomRight: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(100:15)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10, top: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("10元优惠券");
            Text.debugLine("pages/PointCenter.ets(101:17)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(103:17)");
            Row.margin({ top: 2 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("298");
            Text.debugLine("pages/PointCenter.ets(104:19)");
            Text.fontColor(Color.Red);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("积分");
            Text.debugLine("pages/PointCenter.ets(106:19)");
            Text.margin({ left: 3 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("兑换");
            Button.debugLine("pages/PointCenter.ets(111:15)");
            Button.height(30);
            Button.width(56);
            Button.margin({ left: 6 });
            Button.onClick(() => {
                if (this.point >= 298) {
                    this.addCoupon(10);
                    this.subPoint(298);
                }
                else {
                    Util.alert('积分不足');
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(133:11)");
            Column.margin({ top: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
            Image.debugLine("pages/PointCenter.ets(134:13)");
            Image.width(160);
            Image.padding({ left: 20, right: 20 });
            Image.backgroundColor('#ffaedfee');
            Image.borderRadius({ topLeft: 10, topRight: 10 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(140:13)");
            Row.height(50);
            Row.width(160);
            Row.backgroundColor(Color.White);
            Row.borderRadius({ bottomLeft: 10, bottomRight: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(141:15)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10, top: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("20元优惠券");
            Text.debugLine("pages/PointCenter.ets(142:17)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(144:17)");
            Row.margin({ top: 2 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("598");
            Text.debugLine("pages/PointCenter.ets(145:19)");
            Text.fontColor(Color.Red);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("积分");
            Text.debugLine("pages/PointCenter.ets(147:19)");
            Text.margin({ left: 3 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("兑换");
            Button.debugLine("pages/PointCenter.ets(152:15)");
            Button.height(30);
            Button.width(56);
            Button.margin({ left: 6 });
            Button.onClick(() => {
                if (this.point >= 598) {
                    this.addCoupon(20);
                    this.subPoint(598);
                }
                else {
                    Util.alert('积分不足');
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(176:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(177:11)");
            Column.margin({ top: 20, right: 16 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
            Image.debugLine("pages/PointCenter.ets(178:13)");
            Image.width(160);
            Image.padding({ left: 20, right: 20 });
            Image.backgroundColor('#ffaedfee');
            Image.borderRadius({ topLeft: 10, topRight: 10 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(184:13)");
            Row.height(50);
            Row.width(160);
            Row.backgroundColor(Color.White);
            Row.borderRadius({ bottomLeft: 10, bottomRight: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(185:15)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10, top: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("30元优惠券");
            Text.debugLine("pages/PointCenter.ets(186:17)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(188:17)");
            Row.margin({ top: 2 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("899");
            Text.debugLine("pages/PointCenter.ets(189:19)");
            Text.fontColor(Color.Red);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("积分");
            Text.debugLine("pages/PointCenter.ets(191:19)");
            Text.margin({ left: 3 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("兑换");
            Button.debugLine("pages/PointCenter.ets(196:15)");
            Button.height(30);
            Button.width(56);
            Button.margin({ left: 6 });
            Button.onClick(() => {
                if (this.point >= 899) {
                    this.addCoupon(30);
                    this.subPoint(899);
                }
                else {
                    Util.alert('积分不足');
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(218:11)");
            Column.margin({ top: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
            Image.debugLine("pages/PointCenter.ets(219:13)");
            Image.width(160);
            Image.padding({ left: 20, right: 20 });
            Image.backgroundColor('#ffaedfee');
            Image.borderRadius({ topLeft: 10, topRight: 10 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(225:13)");
            Row.height(50);
            Row.width(160);
            Row.backgroundColor(Color.White);
            Row.borderRadius({ bottomLeft: 10, bottomRight: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PointCenter.ets(226:15)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 10, top: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("40元优惠券");
            Text.debugLine("pages/PointCenter.ets(227:17)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PointCenter.ets(229:17)");
            Row.margin({ top: 2 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("1198");
            Text.debugLine("pages/PointCenter.ets(230:19)");
            Text.fontColor(Color.Red);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("积分");
            Text.debugLine("pages/PointCenter.ets(232:19)");
            Text.margin({ left: 3 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("兑换");
            Button.debugLine("pages/PointCenter.ets(237:15)");
            Button.height(30);
            Button.width(56);
            Button.margin({ left: 6 });
            Button.onClick(() => {
                if (this.point >= 1198) {
                    this.addCoupon(40);
                    this.subPoint(1198);
                }
                else {
                    Util.alert('积分不足');
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new PointCenter(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=PointCenter.js.map