import http from '@ohos:net.http';
export class Http {
    constructor(url) {
        this.url = '';
        this.url = url;
    }
    get(data) {
        let params = '';
        if (data) {
            params = '?';
            for (let k in data) {
                params += k + '=' + data[k] + '&';
            } // 可以把最后一个&去掉
            params = params.substring(0, params.length - 1);
        }
        return http.createHttp().request(encodeURI(Http.host + this.url + params));
    }
    parse(resp) {
        let data = `${resp.result}`;
        console.log(data.split('/').join('\\'));
        return JSON.parse(data);
    }
}
Http.host = 'http://localhost:3000';
//# sourceMappingURL=Http.js.map