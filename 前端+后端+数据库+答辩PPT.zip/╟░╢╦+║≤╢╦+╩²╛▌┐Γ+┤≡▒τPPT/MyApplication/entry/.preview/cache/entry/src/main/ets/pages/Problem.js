import router from '@ohos:router';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { Util } from '@bundle:com.example.myapplication/entry/ets/model/Util';
class Problem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__phone = new ObservedPropertySimplePU('', this, "phone");
        this.__detail = new ObservedPropertySimplePU('', this, "detail");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.detail !== undefined) {
            this.detail = params.detail;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__detail.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__phone.aboutToBeDeleted();
        this.__detail.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue) {
        this.__phone.set(newValue);
    }
    get detail() {
        return this.__detail.get();
    }
    set detail(newValue) {
        this.__detail.set(newValue);
    }
    addProblem() {
        let http = new Http('/problem/add/app');
        http.get({
            phone: this.phone,
            detail: this.detail,
        }).then((resp) => {
            resp = http.parse(resp);
            if (resp == 1) {
                Util.alert("提交成功");
                setTimeout(() => {
                    router.back();
                }, 1000);
            }
            else {
                Util.alert("提交失败");
            }
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Problem.ets(35:5)");
            Column.width("100%");
            Column.height('100%');
            Column.backgroundColor('#EEEEEF');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: "问题反馈" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Problem.ets(38:7)");
            Column.width("95%");
            Column.height(140);
            Column.backgroundColor(Color.White);
            Column.margin({ top: 10 });
            Column.borderRadius(15);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Problem.ets(39:9)");
            Row.margin({ left: -140, top: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/iconfont-phone.png');
            Image.debugLine("pages/Problem.ets(40:11)");
            Image.width(34);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("联系方式");
            Text.debugLine("pages/Problem.ets(42:11)");
            Text.fontSize(24);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("pages/Problem.ets(45:9)");
            TextInput.width(300);
            TextInput.margin({ top: 10 });
            TextInput.fontSize(24);
            TextInput.height(40);
            TextInput.onChange(e => {
                this.phone = e;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Problem.ets(59:7)");
            Column.width("95%");
            Column.height(140);
            Column.backgroundColor(Color.White);
            Column.margin({ top: 10 });
            Column.borderRadius(15);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Problem.ets(60:9)");
            Row.margin({ left: -140, top: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/iconfont-shanzi.png');
            Image.debugLine("pages/Problem.ets(61:11)");
            Image.width(34);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("问题描述");
            Text.debugLine("pages/Problem.ets(63:11)");
            Text.fontSize(24);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("pages/Problem.ets(66:9)");
            TextInput.width(300);
            TextInput.margin({ top: 10 });
            TextInput.fontSize(24);
            TextInput.height(40);
            TextInput.onChange(e => {
                this.detail = e;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("提交反馈");
            Button.debugLine("pages/Problem.ets(80:7)");
            Button.margin({ top: 260 });
            Button.width(170);
            Button.onClick(() => {
                this.addProblem();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Problem(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Problem.js.map