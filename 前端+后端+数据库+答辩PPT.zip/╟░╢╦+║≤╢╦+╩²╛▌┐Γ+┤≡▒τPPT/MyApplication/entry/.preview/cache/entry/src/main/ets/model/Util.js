import promptAction from '@ohos:promptAction';
export class Util {
    static alert(msg) {
        promptAction.showToast({
            message: msg + ''
        });
    }
}
//# sourceMappingURL=Util.js.map