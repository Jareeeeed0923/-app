import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { User } from '@bundle:com.example.myapplication/entry/ets/model/Bean';
import router from '@ohos:router';
import { TitleBarNoBack } from '@bundle:com.example.myapplication/entry/ets/components/TitileBarNoBack';
function __Image__funImageClass() {
    Image.width(60);
    Image.height(60);
}
function __Text__funTextClass() {
    Text.fontWeight(20);
}
function __Column__funColumnClass() {
    Column.margin(5);
}
export class BarMy extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__user = new ObservedPropertyObjectPU(new User(), this, "user");
        this.__point = new ObservedPropertySimplePU(0, this, "point");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__totOfCoupon = new ObservedPropertySimplePU(0, this, "totOfCoupon");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.uid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.user !== undefined) {
            this.user = params.user;
        }
        if (params.point !== undefined) {
            this.point = params.point;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.totOfCoupon !== undefined) {
            this.totOfCoupon = params.totOfCoupon;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__user.purgeDependencyOnElmtId(rmElmtId);
        this.__point.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__totOfCoupon.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__user.aboutToBeDeleted();
        this.__point.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__totOfCoupon.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get user() {
        return this.__user.get();
    }
    set user(newValue) {
        this.__user.set(newValue);
    }
    get point() {
        return this.__point.get();
    }
    set point(newValue) {
        this.__point.set(newValue);
    }
    get username() {
        return this.__username.get();
    }
    set username(newValue) {
        this.__username.set(newValue);
    }
    get totOfCoupon() {
        return this.__totOfCoupon.get();
    }
    set totOfCoupon(newValue) {
        this.__totOfCoupon.set(newValue);
    }
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue) {
        this.__isRefreshing.set(newValue);
    }
    aboutToAppear() {
        this.uid = router.getParams()['uid'];
        this.getUser();
        this.getNumOfCoupon();
    }
    getUser() {
        let http = new Http('/user/askById/app?id=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.user = resp.user[0];
            this.point = this.user.point;
            this.username = this.user.username;
        });
    }
    getNumOfCoupon() {
        let http = new Http('/coupon/getNumById/app?uid=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.totOfCoupon = resp.tot[0].x;
        });
    }
    toCoupon() {
        router.pushUrl({
            url: 'pages/MyCoupon',
            params: {
                uid: this.uid,
            }
        });
    }
    toPointCenter() {
        router.pushUrl({
            url: 'pages/PointCenter',
            params: {
                uid: this.uid,
            }
        });
    }
    toWelfareGroup() {
        router.pushUrl({
            url: 'pages/WelfareGroup',
        });
    }
    toCouponByConsume() {
        router.pushUrl({
            url: 'pages/CouponByConsume',
            params: {
                uid: this.uid,
            }
        });
    }
    toMyCoupon() {
        router.pushUrl({
            url: 'pages/MyCoupon',
            params: {
                uid: this.uid,
            }
        });
    }
    toProblem() {
        router.pushUrl({
            url: 'pages/Problem',
            params: {
                uid: this.uid,
            }
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Refresh.create({ refreshing: { value: this.isRefreshing, changeEvent: newValue => { this.isRefreshing = newValue; } }, offset: 120, friction: 100 });
            Refresh.debugLine("components/BarMy.ets(118:5)");
            Refresh.onRefreshing(() => {
                setTimeout(() => {
                    this.getUser();
                    this.getNumOfCoupon();
                    this.isRefreshing = false;
                }, 500);
            });
            if (!isInitialRender) {
                Refresh.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(119:7)");
            Column.height('100%');
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBarNoBack(this, { title: '会员中心' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(122:9)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarMy.ets(123:11)");
            Row.margin({ top: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%B8%AA%E4%BA%BA%E4%B8%AD%E5%BF%83.png");
            Image.debugLine("components/BarMy.ets(124:13)");
            Image.width(90);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(127:13)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.username);
            Text.debugLine("components/BarMy.ets(128:15)");
            Text.fontSize(23);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarMy.ets(130:17)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("会员积分：");
            Text.debugLine("components/BarMy.ets(131:19)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E9%87%91%E5%B8%81.png");
            Image.debugLine("components/BarMy.ets(132:19)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.point.toString());
            Text.debugLine("components/BarMy.ets(134:19)");
            Text.fontSize(20);
            Text.margin({ left: 3 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(143:11)");
            Column.width(300);
            Column.height(80);
            Column.backgroundColor('#ffa6dce9');
            Column.borderRadius(10);
            Column.margin({ top: 10 });
            Column.onClick(() => {
                this.toCoupon();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarMy.ets(144:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(145:15)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.totOfCoupon.toString());
            Text.debugLine("components/BarMy.ets(146:17)");
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(26);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("优惠券");
            Text.debugLine("components/BarMy.ets(149:17)");
            Text.fontSize(16);
            Text.margin({ top: 8 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png");
            Image.debugLine("components/BarMy.ets(154:15)");
            Image.width(80);
            Image.margin({ left: 100 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("更多服务");
            Text.debugLine("components/BarMy.ets(167:11)");
            Text.fontSize(20);
            Text.padding({ top: 20, bottom: 20 });
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(172:11)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarMy.ets(173:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(174:15)");
            __Column__funColumnClass();
            Column.onClick(() => {
                this.toPointCenter();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/fun1.png');
            Image.debugLine("components/BarMy.ets(175:17)");
            __Image__funImageClass();
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('积分中心');
            Text.debugLine("components/BarMy.ets(177:17)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(183:15)");
            Column.margin(20);
            __Column__funColumnClass();
            Column.onClick(() => {
                this.toWelfareGroup();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/fun2.png');
            Image.debugLine("components/BarMy.ets(184:17)");
            __Image__funImageClass();
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('福利群');
            Text.debugLine("components/BarMy.ets(186:17)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(193:15)");
            __Column__funColumnClass();
            Column.onClick(() => {
                this.toProblem();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/fun3.png');
            Image.debugLine("components/BarMy.ets(194:17)");
            __Image__funImageClass();
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('问题反馈');
            Text.debugLine("components/BarMy.ets(196:17)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(202:15)");
            __Column__funColumnClass();
            Column.onClick(() => {
                this.toCouponByConsume();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/fun4.png');
            Image.debugLine("components/BarMy.ets(203:17)");
            __Image__funImageClass();
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('消费领券');
            Text.debugLine("components/BarMy.ets(205:17)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarMy.ets(212:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarMy.ets(213:15)");
            __Column__funColumnClass();
            Column.margin({ left: -218 });
            Column.onClick(() => {
                this.toMyCoupon();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/fun5.png');
            Image.debugLine("components/BarMy.ets(214:17)");
            __Image__funImageClass();
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('优惠券');
            Text.debugLine("components/BarMy.ets(216:17)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
        Column.pop();
        Column.pop();
        Column.pop();
        Refresh.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "BarMy", new BarMy(undefined, {}));
}
//# sourceMappingURL=BarMy.js.map