import router from '@ohos:router';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { Util } from '@bundle:com.example.myapplication/entry/ets/model/Util';
// css区域：专门写css
function __TextInput__LoginInputText() {
    TextInput.margin({ top: 30 });
    TextInput.fontSize(20);
    TextInput.placeholderFont({ size: 20 });
    TextInput.backgroundColor(Color.White);
    TextInput.borderRadius(0);
    TextInput.borderWidth({ bottom: 1 });
    TextInput.borderColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
}
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__username = new ObservedPropertySimplePU('张三' // 这个地方必须要写类型，没有类型推断
        , this, "username");
        this.__password = new ObservedPropertySimplePU('123', this, "password");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get username() {
        return this.__username.get();
    }
    set username(newValue) {
        this.__username.set(newValue);
    }
    get password() {
        return this.__password.get();
    }
    set password(newValue) {
        this.__password.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Login.ets(30:5)");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("pages/Login.ets(31:7)");
            Image.width(150);
            Image.height(150);
            Image.borderRadius(75);
            Image.margin({ top: 30, bottom: 20 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: '请输入用户名', text: this.username
            });
            TextInput.debugLine("pages/Login.ets(37:7)");
            __TextInput__LoginInputText();
            TextInput.onChange(e => {
                this.username = e;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({
                placeholder: '请输入密码', text: this.password
            });
            TextInput.debugLine("pages/Login.ets(44:7)");
            __TextInput__LoginInputText();
            TextInput.onChange(e => {
                this.password = e;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 华为预览器有一个非常难受的bug，输入框写不了中文
            Button.createWithLabel('登录');
            Button.debugLine("pages/Login.ets(52:7)");
            // 华为预览器有一个非常难受的bug，输入框写不了中文
            Button.width('50%');
            // 华为预览器有一个非常难受的bug，输入框写不了中文
            Button.margin({ top: 50 });
            // 华为预览器有一个非常难受的bug，输入框写不了中文
            Button.onClick(() => {
                // 提交订单和登录思路是一样的
                // 方法一
                // 方法二 {}--->自动帮你拼接成?传参
                let http = new Http('/ellogin');
                http.get({
                    username: this.username,
                    password: this.password
                }).then((resp) => {
                    resp = http.parse(resp); // 解析数据，必须要有
                    if (resp.code) { // ==1
                        router.pushUrl({
                            url: 'pages/MainPage',
                            params: {
                                // 这里是打开index页面带一个uid
                                uid: resp.uid
                            }
                        });
                    }
                    else { // ==0  登录失败
                        Util.alert('用户名或密码错误');
                    }
                });
            });
            if (!isInitialRender) {
                // 华为预览器有一个非常难受的bug，输入框写不了中文
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 华为预览器有一个非常难受的bug，输入框写不了中文
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Login(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Login.js.map