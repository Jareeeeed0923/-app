import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import router from '@ohos:router';
function __Stack__IndexCategory() {
    Stack.width('100%');
    Stack.borderWidth({ bottom: 1, right: 1 });
    Stack.borderColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
    Stack.alignContent(Alignment.Bottom);
}
function __Row__IndexFood() {
    Row.width('100%');
    Row.borderWidth({ bottom: 1 });
    Row.borderColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
    Row.alignItems(VerticalAlign.Top);
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__categorys = new ObservedPropertyObjectPU([], this, "categorys");
        this.__hots = new ObservedPropertyObjectPU(['111'] //不加就会崩
        , this, "hots");
        this.__foods = new ObservedPropertyObjectPU([], this, "foods");
        this.__index = new ObservedPropertySimplePU(0, this, "index");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__cid = new ObservedPropertySimplePU(0
        //不需要显示在页面的变量就不用写@State双向绑定
        , this, "cid");
        this.uid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.categorys !== undefined) {
            this.categorys = params.categorys;
        }
        if (params.hots !== undefined) {
            this.hots = params.hots;
        }
        if (params.foods !== undefined) {
            this.foods = params.foods;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.cid !== undefined) {
            this.cid = params.cid;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__categorys.purgeDependencyOnElmtId(rmElmtId);
        this.__hots.purgeDependencyOnElmtId(rmElmtId);
        this.__foods.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__cid.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__categorys.aboutToBeDeleted();
        this.__hots.aboutToBeDeleted();
        this.__foods.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__cid.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get categorys() {
        return this.__categorys.get();
    }
    set categorys(newValue) {
        this.__categorys.set(newValue);
    }
    get hots() {
        return this.__hots.get();
    }
    set hots(newValue) {
        this.__hots.set(newValue);
    }
    get foods() {
        return this.__foods.get();
    }
    set foods(newValue) {
        this.__foods.set(newValue);
    }
    get index() {
        return this.__index.get();
    }
    set index(newValue) {
        this.__index.set(newValue);
    }
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue) {
        this.__isRefreshing.set(newValue);
    }
    get cid() {
        return this.__cid.get();
    }
    set cid(newValue) {
        this.__cid.set(newValue);
    }
    aboutToAppear() {
        this.uid = router.getParams()['uid'];
        //发起http请求，访问express数据接口。
        let http = new Http('/food/index/app');
        http.get().then((resp) => {
            resp = http.parse(resp); //parse解析数据
            // promptAction.showToast({ //弹出提示语
            //   message:resp.categorys[0].category
            // })
            this.categorys = resp.categorys;
            if (this.categorys.length) { // 取第一个类别的东西
                this.cid = this.categorys[0].id;
            }
            this.hots = resp.hots; //热卖图片列表
            this.foods = resp.foods; //右侧的1
        });
    }
    //定义函数千万别加function
    switchMenu(cid) {
        let http = new Http('/food/menu/app?cid=' + cid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.foods = resp.foods; //传回来的数据一定要有foods
        });
    }
    //放UI
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //垂直容器
            //仅能有一个根组件：Column
            Refresh.create({ refreshing: { value: this.isRefreshing, changeEvent: newValue => { this.isRefreshing = newValue; } }, offset: 120, friction: 100 });
            Refresh.debugLine("pages/Index.ets(73:5)");
            //垂直容器
            //仅能有一个根组件：Column
            Refresh.onRefreshing(() => {
                setTimeout(() => {
                    this.switchMenu(this.cid);
                    this.isRefreshing = false;
                }, 500);
            });
            if (!isInitialRender) {
                //垂直容器
                //仅能有一个根组件：Column
                Refresh.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //这里面可以有多个Column并列
            //Stack层叠组件，里面的组件会产生层叠效果
            Column.create();
            Column.debugLine("pages/Index.ets(76:7)");
            //这里面可以有多个Column并列
            //Stack层叠组件，里面的组件会产生层叠效果
            Column.width('100%');
            //这里面可以有多个Column并列
            //Stack层叠组件，里面的组件会产生层叠效果
            Column.height('100%');
            if (!isInitialRender) {
                //这里面可以有多个Column并列
                //Stack层叠组件，里面的组件会产生层叠效果
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: '点餐' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //swiper
            if (this.hots.length) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Swiper.create();
                        Swiper.debugLine("pages/Index.ets(83:11)");
                        Swiper.autoPlay(true);
                        Swiper.interval(3000);
                        Swiper.duration(1000);
                        if (!isInitialRender) {
                            Swiper.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Image.create(item);
                                Image.debugLine("pages/Index.ets(85:15)");
                                Image.width('100%');
                                Image.height(180);
                                if (!isInitialRender) {
                                    Image.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        };
                        this.forEachUpdateFunction(elmtId, this.hots, forEachItemGenFunction);
                        if (!isInitialRender) {
                            ForEach.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    ForEach.pop();
                    Swiper.pop();
                });
            }
            // List列表是祖孙三代
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // List列表是祖孙三代
            Row.create();
            Row.debugLine("pages/Index.ets(94:9)");
            // List列表是祖孙三代
            Row.layoutWeight(1);
            // List列表是祖孙三代
            Row.width('100%');
            if (!isInitialRender) {
                // List列表是祖孙三代
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Index.ets(95:11)");
            List.height('100%');
            List.width('25%');
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, i) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/Index.ets(97:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Stack.create();
                            Stack.debugLine("pages/Index.ets(98:17)");
                            __Stack__IndexCategory();
                            Stack.onClick(() => {
                                this.index = i;
                                this.cid = item.id; //点的
                                this.switchMenu(item.id);
                            });
                            if (!isInitialRender) {
                                Stack.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.category);
                            Text.debugLine("pages/Index.ets(99:19)");
                            Text.padding({ top: 10, bottom: 10 });
                            Text.fontColor(this.index == i ? { "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" } : Color.Gray);
                            Text.fontWeight(this.index == i ? FontWeight.Bold : FontWeight.Normal);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (this.index == i) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Line.create();
                                        Line.debugLine("pages/Index.ets(104:21)");
                                        Line.height(5);
                                        Line.width('100%');
                                        Line.backgroundColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                                        if (!isInitialRender) {
                                            Line.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                });
                            }
                            else {
                                If.branchId(1);
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Stack.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Stack.create();
                            Stack.debugLine("pages/Index.ets(98:17)");
                            __Stack__IndexCategory();
                            Stack.onClick(() => {
                                this.index = i;
                                this.cid = item.id; //点的
                                this.switchMenu(item.id);
                            });
                            if (!isInitialRender) {
                                Stack.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.category);
                            Text.debugLine("pages/Index.ets(99:19)");
                            Text.padding({ top: 10, bottom: 10 });
                            Text.fontColor(this.index == i ? { "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" } : Color.Gray);
                            Text.fontWeight(this.index == i ? FontWeight.Bold : FontWeight.Normal);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (this.index == i) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Line.create();
                                        Line.debugLine("pages/Index.ets(104:21)");
                                        Line.height(5);
                                        Line.width('100%');
                                        Line.backgroundColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                                        if (!isInitialRender) {
                                            Line.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                });
                            }
                            else {
                                If.branchId(1);
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Stack.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.categorys, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Index.ets(120:11)");
            List.height('100%');
            List.width('75%');
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, i) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/Index.ets(122:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/Index.ets(123:17)");
                            __Row__IndexFood();
                            Row.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/Order',
                                    params: {
                                        uid: this.uid,
                                        fid: item.id,
                                        food: item.food,
                                        logo: item.logo,
                                    }
                                });
                            });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.logo);
                            Image.debugLine("pages/Index.ets(124:19)");
                            Image.width(70);
                            Image.height(70);
                            Image.margin(10);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/Index.ets(128:19)");
                            Column.layoutWeight(1);
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.food);
                            Text.debugLine("pages/Index.ets(129:21)");
                            Text.margin({ top: 20 });
                            Text.fontWeight(FontWeight.Bold);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.price + '元');
                            Text.debugLine("pages/Index.ets(132:21)");
                            Text.fontColor(Color.Gray);
                            Text.margin({ top: 10 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/Index.ets(123:17)");
                            __Row__IndexFood();
                            Row.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/Order',
                                    params: {
                                        uid: this.uid,
                                        fid: item.id,
                                        food: item.food,
                                        logo: item.logo,
                                    }
                                });
                            });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.logo);
                            Image.debugLine("pages/Index.ets(124:19)");
                            Image.width(70);
                            Image.height(70);
                            Image.margin(10);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/Index.ets(128:19)");
                            Column.layoutWeight(1);
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.food);
                            Text.debugLine("pages/Index.ets(129:21)");
                            Text.margin({ top: 20 });
                            Text.fontWeight(FontWeight.Bold);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.price + '元');
                            Text.debugLine("pages/Index.ets(132:21)");
                            Text.fontColor(Color.Gray);
                            Text.margin({ top: 10 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.foods, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        // List列表是祖孙三代
        Row.pop();
        //这里面可以有多个Column并列
        //Stack层叠组件，里面的组件会产生层叠效果
        Column.pop();
        //垂直容器
        //仅能有一个根组件：Column
        Refresh.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map