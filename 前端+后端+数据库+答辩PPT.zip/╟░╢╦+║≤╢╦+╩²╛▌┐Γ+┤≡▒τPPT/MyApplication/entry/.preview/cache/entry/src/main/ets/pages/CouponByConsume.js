import router from '@ohos:router';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { Util } from '@bundle:com.example.myapplication/entry/ets/model/Util';
class CouponByConsume extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__coupon = new ObservedPropertyObjectPU([], this, "coupon");
        this.__gotCoupon = new ObservedPropertyObjectPU([], this, "gotCoupon");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.uid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.coupon !== undefined) {
            this.coupon = params.coupon;
        }
        if (params.gotCoupon !== undefined) {
            this.gotCoupon = params.gotCoupon;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__coupon.purgeDependencyOnElmtId(rmElmtId);
        this.__gotCoupon.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__coupon.aboutToBeDeleted();
        this.__gotCoupon.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get coupon() {
        return this.__coupon.get();
    }
    set coupon(newValue) {
        this.__coupon.set(newValue);
    }
    get gotCoupon() {
        return this.__gotCoupon.get();
    }
    set gotCoupon(newValue) {
        this.__gotCoupon.set(newValue);
    }
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue) {
        this.__isRefreshing.set(newValue);
    }
    getGotCoupon() {
        let http = new Http('/couponByConsume/getByuid/app?uid=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.gotCoupon = resp.gotCoupon;
        });
    }
    addCoupon() {
        let http = new Http('/coupon/addCoupon/app');
        http.get({
            uid: this.uid,
            value: 10,
            name: '10元优惠券',
            useful: 1
        }).then((resp) => {
            resp = http.parse(resp);
            if (resp == 1) {
                Util.alert('领取成功');
            }
            else {
                Util.alert(resp);
            }
        });
    }
    receiveCoupon(cid) {
        let http = new Http('/couponByConsume/deleteByid/app?id=' + cid);
        http.get().then((resp) => {
            resp = http.parse(resp);
        });
        this.addCoupon();
    }
    aboutToAppear() {
        this.uid = router.getParams()['uid'];
        this.getGotCoupon();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Refresh.create({ refreshing: { value: this.isRefreshing, changeEvent: newValue => { this.isRefreshing = newValue; } }, offset: 120, friction: 100 });
            Refresh.debugLine("pages/CouponByConsume.ets(63:5)");
            Refresh.onRefreshing(() => {
                setTimeout(() => {
                    this.getGotCoupon();
                    this.isRefreshing = false;
                }, 500);
            });
            if (!isInitialRender) {
                Refresh.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/CouponByConsume.ets(64:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: '领取优惠券' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/CouponByConsume.ets(67:7)");
            Column.backgroundColor('#ffeaeaea');
            Column.height('100%');
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/CouponByConsume.ets(69:9)");
            Row.margin({ bottom: 70 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/CouponByConsume.ets(70:11)");
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, i) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/CouponByConsume.ets(72:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/CouponByConsume.ets(73:17)");
                            Column.height(90);
                            Column.backgroundColor(Color.White);
                            Column.width('95%');
                            Column.borderRadius(10);
                            Column.margin({ left: 8, top: 10 });
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/CouponByConsume.ets(75:19)");
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
                            Image.debugLine("pages/CouponByConsume.ets(76:21)");
                            Image.width(90);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/CouponByConsume.ets(78:21)");
                            Column.margin({ left: 60 });
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create("10元优惠券");
                            Text.debugLine("pages/CouponByConsume.ets(79:23)");
                            Text.fontSize(20);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create("价值:￥10");
                            Text.debugLine("pages/CouponByConsume.ets(81:23)");
                            Text.margin({ top: 6 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Button.createWithLabel("领取");
                            Button.debugLine("pages/CouponByConsume.ets(86:21)");
                            Button.margin({ left: 10 });
                            Button.onClick(() => {
                                this.receiveCoupon(item.id);
                            });
                            if (!isInitialRender) {
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Button.pop();
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/CouponByConsume.ets(73:17)");
                            Column.height(90);
                            Column.backgroundColor(Color.White);
                            Column.width('95%');
                            Column.borderRadius(10);
                            Column.margin({ left: 8, top: 10 });
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/CouponByConsume.ets(75:19)");
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
                            Image.debugLine("pages/CouponByConsume.ets(76:21)");
                            Image.width(90);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/CouponByConsume.ets(78:21)");
                            Column.margin({ left: 60 });
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create("10元优惠券");
                            Text.debugLine("pages/CouponByConsume.ets(79:23)");
                            Text.fontSize(20);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create("价值:￥10");
                            Text.debugLine("pages/CouponByConsume.ets(81:23)");
                            Text.margin({ top: 6 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Button.createWithLabel("领取");
                            Button.debugLine("pages/CouponByConsume.ets(86:21)");
                            Button.margin({ left: 10 });
                            Button.onClick(() => {
                                this.receiveCoupon(item.id);
                            });
                            if (!isInitialRender) {
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Button.pop();
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.gotCoupon, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Row.pop();
        Column.pop();
        Column.pop();
        Refresh.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new CouponByConsume(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=CouponByConsume.js.map