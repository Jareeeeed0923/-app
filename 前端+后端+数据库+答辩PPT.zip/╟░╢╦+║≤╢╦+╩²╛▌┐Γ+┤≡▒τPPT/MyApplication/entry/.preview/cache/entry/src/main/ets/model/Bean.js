export class Category {
}
export class Food {
}
export class VOrder {
}
export class Order {
}
export class User {
}
export class Coupon {
}
export class GotCoupon {
}
//# sourceMappingURL=Bean.js.map