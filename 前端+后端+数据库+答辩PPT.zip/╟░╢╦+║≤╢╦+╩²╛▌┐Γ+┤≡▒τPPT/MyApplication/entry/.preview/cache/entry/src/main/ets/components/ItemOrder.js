import router from '@ohos:router';
import { Order } from '@bundle:com.example.myapplication/entry/ets/model/Bean';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
export class ItemOrder extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__logo = new ObservedPropertySimplePU('', this, "logo");
        this.__food = new ObservedPropertySimplePU('', this, "food");
        this.__phone = new ObservedPropertySimplePU('', this, "phone");
        this.__count = new ObservedPropertySimplePU(0, this, "count");
        this.__price = new ObservedPropertySimplePU(0, this, "price");
        this.__oid = new ObservedPropertySimplePU(0, this, "oid");
        this.__uid = new ObservedPropertySimplePU(0, this, "uid");
        this.__order = new ObservedPropertyObjectPU(new Order(), this, "order");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.logo !== undefined) {
            this.logo = params.logo;
        }
        if (params.food !== undefined) {
            this.food = params.food;
        }
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.count !== undefined) {
            this.count = params.count;
        }
        if (params.price !== undefined) {
            this.price = params.price;
        }
        if (params.oid !== undefined) {
            this.oid = params.oid;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
        if (params.order !== undefined) {
            this.order = params.order;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__logo.purgeDependencyOnElmtId(rmElmtId);
        this.__food.purgeDependencyOnElmtId(rmElmtId);
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__count.purgeDependencyOnElmtId(rmElmtId);
        this.__price.purgeDependencyOnElmtId(rmElmtId);
        this.__oid.purgeDependencyOnElmtId(rmElmtId);
        this.__uid.purgeDependencyOnElmtId(rmElmtId);
        this.__order.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__logo.aboutToBeDeleted();
        this.__food.aboutToBeDeleted();
        this.__phone.aboutToBeDeleted();
        this.__count.aboutToBeDeleted();
        this.__price.aboutToBeDeleted();
        this.__oid.aboutToBeDeleted();
        this.__uid.aboutToBeDeleted();
        this.__order.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get logo() {
        return this.__logo.get();
    }
    set logo(newValue) {
        this.__logo.set(newValue);
    }
    get food() {
        return this.__food.get();
    }
    set food(newValue) {
        this.__food.set(newValue);
    }
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue) {
        this.__phone.set(newValue);
    }
    get count() {
        return this.__count.get();
    }
    set count(newValue) {
        this.__count.set(newValue);
    }
    get price() {
        return this.__price.get();
    }
    set price(newValue) {
        this.__price.set(newValue);
    }
    get oid() {
        return this.__oid.get();
    }
    set oid(newValue) {
        this.__oid.set(newValue);
    }
    get uid() {
        return this.__uid.get();
    }
    set uid(newValue) {
        this.__uid.set(newValue);
    }
    get order() {
        return this.__order.get();
    }
    set order(newValue) {
        this.__order.set(newValue);
    }
    aboutToAppear() {
        this.uid = router.getParams()['uid'];
    }
    buyAnother(food) {
        let http = new Http('/order/askById/app?id=' + this.oid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.order = resp.order[0]; //传回来的数据一定要有foods
        });
        router.pushUrl({
            url: 'pages/Order',
            params: {
                cid: 0,
                uid: this.uid,
                fid: this.order.fid,
                food: this.food,
                logo: this.logo,
                price: this.price
            }
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/ItemOrder.ets(44:5)");
            Column.backgroundColor(Color.White);
            Column.width('92%');
            Column.margin({ top: 15, left: 14 });
            Column.padding(20);
            Column.borderRadius(10);
            Column.alignItems(HorizontalAlign.Start);
            Column.onClick(() => {
                router.pushUrl({
                    url: 'pages/OrderDetail',
                    params: {
                        oid: this.oid
                    }
                });
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/ItemOrder.ets(45:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.logo);
            Image.debugLine("components/ItemOrder.ets(46:9)");
            Image.width(100);
            Image.height(100);
            Image.borderRadius(10);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/ItemOrder.ets(50:9)");
            Column.margin({ left: 20 });
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.food);
            Text.debugLine("components/ItemOrder.ets(51:11)");
            Text.margin({ top: 0 });
            Text.fontSize('20fp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/ItemOrder.ets(54:11)");
            Row.margin({ top: 20, left: 90 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("共" + this.count + "件");
            Text.debugLine("components/ItemOrder.ets(55:13)");
            Text.fontColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("￥" + (this.count * this.price).toString());
            Text.debugLine("components/ItemOrder.ets(57:13)");
            Text.fontSize('20fp');
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('再来一单');
            Button.debugLine("components/ItemOrder.ets(63:11)");
            Button.margin({ top: 10, left: 85 });
            Button.width(80);
            Button.height(35);
            Button.onClick(() => {
                this.buyAnother(this.food);
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "ItemOrder", new ItemOrder(undefined, {}));
}
//# sourceMappingURL=ItemOrder.js.map