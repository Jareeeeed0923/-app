import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import router from '@ohos:router';
import { TitleBarNoBack } from '@bundle:com.example.myapplication/entry/ets/components/TitileBarNoBack';
function __Stack__IndexCategory() {
    Stack.width('100%');
    Stack.borderColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
    Stack.alignContent(Alignment.Bottom);
}
function __Row__IndexFood() {
    Row.width('100%');
    Row.borderColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
    Row.alignItems(VerticalAlign.Top);
}
export class BarBuy extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__categorys = new ObservedPropertyObjectPU([], this, "categorys");
        this.__hots = new ObservedPropertyObjectPU(['111'] //不加就会崩
        , this, "hots");
        this.__foods = new ObservedPropertyObjectPU([], this, "foods");
        this.__index = new ObservedPropertySimplePU(0, this, "index");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__cid = new ObservedPropertySimplePU(0
        //不需要显示在页面的变量就不用写@State双向绑定
        , this, "cid");
        this.uid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.categorys !== undefined) {
            this.categorys = params.categorys;
        }
        if (params.hots !== undefined) {
            this.hots = params.hots;
        }
        if (params.foods !== undefined) {
            this.foods = params.foods;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.cid !== undefined) {
            this.cid = params.cid;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__categorys.purgeDependencyOnElmtId(rmElmtId);
        this.__hots.purgeDependencyOnElmtId(rmElmtId);
        this.__foods.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__cid.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__categorys.aboutToBeDeleted();
        this.__hots.aboutToBeDeleted();
        this.__foods.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__cid.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get categorys() {
        return this.__categorys.get();
    }
    set categorys(newValue) {
        this.__categorys.set(newValue);
    }
    get hots() {
        return this.__hots.get();
    }
    set hots(newValue) {
        this.__hots.set(newValue);
    }
    get foods() {
        return this.__foods.get();
    }
    set foods(newValue) {
        this.__foods.set(newValue);
    }
    get index() {
        return this.__index.get();
    }
    set index(newValue) {
        this.__index.set(newValue);
    }
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue) {
        this.__isRefreshing.set(newValue);
    }
    get cid() {
        return this.__cid.get();
    }
    set cid(newValue) {
        this.__cid.set(newValue);
    }
    aboutToAppear() {
        this.uid = parseInt(router.getParams()['uid']);
        //发起http请求，访问express数据接口。
        let http = new Http('/food/index/app');
        http.get().then((resp) => {
            resp = http.parse(resp); //parse解析数据
            // promptAction.showToast({ //弹出提示语
            //   message:resp.categorys[0].category
            // })
            this.categorys = resp.categorys;
            if (this.categorys.length) { // 取第一个类别的东西
                this.cid = this.categorys[0].id;
            }
            this.hots = resp.hots; //热卖图片列表
            this.foods = resp.foods; //右侧的1
        });
    }
    //定义函数千万别加function
    switchMenu(cid) {
        let http = new Http('/food/menu/app?cid=' + cid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.foods = resp.foods; //传回来的数据一定要有foods
        });
    }
    toCouponByConsume() {
        router.pushUrl({
            url: 'pages/CouponByConsume',
            params: {
                uid: this.uid,
            }
        });
    }
    //放UI
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //垂直容器
            //仅能有一个根组件：Column
            Refresh.create({ refreshing: { value: this.isRefreshing, changeEvent: newValue => { this.isRefreshing = newValue; } }, offset: 120, friction: 100 });
            Refresh.debugLine("components/BarBuy.ets(84:5)");
            //垂直容器
            //仅能有一个根组件：Column
            Refresh.onRefreshing(() => {
                setTimeout(() => {
                    this.switchMenu(this.cid);
                    this.isRefreshing = false;
                }, 500);
            });
            if (!isInitialRender) {
                //垂直容器
                //仅能有一个根组件：Column
                Refresh.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //这里面可以有多个Column并列
            //Stack层叠组件，里面的组件会产生层叠效果
            Column.create();
            Column.debugLine("components/BarBuy.ets(87:7)");
            //这里面可以有多个Column并列
            //Stack层叠组件，里面的组件会产生层叠效果
            Column.width('100%');
            //这里面可以有多个Column并列
            //Stack层叠组件，里面的组件会产生层叠效果
            Column.height('100%');
            if (!isInitialRender) {
                //这里面可以有多个Column并列
                //Stack层叠组件，里面的组件会产生层叠效果
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBarNoBack(this, { title: '点餐' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Stack() {
            //   APIMarquee({src: "❤珍惜粮食，按需点餐~"})
            // }
            // .height(45)
            // .align(Alignment.TopStart)
            Column.create();
            Column.debugLine("components/BarBuy.ets(97:9)");
            // Stack() {
            //   APIMarquee({src: "❤珍惜粮食，按需点餐~"})
            // }
            // .height(45)
            // .align(Alignment.TopStart)
            Column.width('100%');
            // Stack() {
            //   APIMarquee({src: "❤珍惜粮食，按需点餐~"})
            // }
            // .height(45)
            // .align(Alignment.TopStart)
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                // Stack() {
                //   APIMarquee({src: "❤珍惜粮食，按需点餐~"})
                // }
                // .height(45)
                // .align(Alignment.TopStart)
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarBuy.ets(99:11)");
            Column.alignItems(HorizontalAlign.Start);
            Column.backgroundColor('#ffaadefa');
            Column.height(55);
            Column.width("95%");
            Column.margin({ top: 10, bottom: 10, left: 5, right: 5 });
            Column.borderRadius(10);
            Column.onClick(() => {
                this.toCouponByConsume();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarBuy.ets(100:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E7%BA%A2%E5%8C%85.png");
            Image.debugLine("components/BarBuy.ets(101:15)");
            Image.width(55);
            Image.height(55);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarBuy.ets(104:15)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("限时优惠活动");
            Text.debugLine("components/BarBuy.ets(105:17)");
            Text.margin({ top: 5 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("本店单次消费50元得10元代金券");
            Text.debugLine("components/BarBuy.ets(107:17)");
            Text.margin({ top: 5 });
            Text.fontSize(14);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
        Column.pop();
        // Stack() {
        //   APIMarquee({src: "❤珍惜粮食，按需点餐~"})
        // }
        // .height(45)
        // .align(Alignment.TopStart)
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // List列表是祖孙三代
            Row.create();
            Row.debugLine("components/BarBuy.ets(128:9)");
            // List列表是祖孙三代
            Row.layoutWeight(1);
            // List列表是祖孙三代
            Row.width('100%');
            // List列表是祖孙三代
            Row.backgroundColor('#FFEEEEEE');
            if (!isInitialRender) {
                // List列表是祖孙三代
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //左侧类别
            List.create();
            List.debugLine("components/BarBuy.ets(131:11)");
            //左侧类别
            List.height('100%');
            //左侧类别
            List.backgroundColor(Color.White);
            //左侧类别
            List.width('25%');
            if (!isInitialRender) {
                //左侧类别
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, i) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("components/BarBuy.ets(133:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Stack.create();
                            Stack.debugLine("components/BarBuy.ets(134:17)");
                            __Stack__IndexCategory();
                            Stack.onClick(() => {
                                this.index = i;
                                this.cid = item.id; //点的
                                this.switchMenu(item.id);
                            });
                            if (!isInitialRender) {
                                Stack.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.category);
                            Text.debugLine("components/BarBuy.ets(135:19)");
                            Text.padding({ top: 15, bottom: 15 });
                            Text.fontColor(this.index == i ? { "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" } : Color.Gray);
                            Text.fontWeight(this.index == i ? FontWeight.Bold : FontWeight.Normal);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (this.index == i) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Line.create();
                                        Line.debugLine("components/BarBuy.ets(140:21)");
                                        Line.height(5);
                                        Line.width('100%');
                                        Line.backgroundColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                                        if (!isInitialRender) {
                                            Line.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                });
                            }
                            else {
                                If.branchId(1);
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Stack.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Stack.create();
                            Stack.debugLine("components/BarBuy.ets(134:17)");
                            __Stack__IndexCategory();
                            Stack.onClick(() => {
                                this.index = i;
                                this.cid = item.id; //点的
                                this.switchMenu(item.id);
                            });
                            if (!isInitialRender) {
                                Stack.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.category);
                            Text.debugLine("components/BarBuy.ets(135:19)");
                            Text.padding({ top: 15, bottom: 15 });
                            Text.fontColor(this.index == i ? { "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" } : Color.Gray);
                            Text.fontWeight(this.index == i ? FontWeight.Bold : FontWeight.Normal);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (this.index == i) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Line.create();
                                        Line.debugLine("components/BarBuy.ets(140:21)");
                                        Line.height(5);
                                        Line.width('100%');
                                        Line.backgroundColor({ "id": 16777231, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                                        if (!isInitialRender) {
                                            Line.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                });
                            }
                            else {
                                If.branchId(1);
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Stack.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.categorys, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        //左侧类别
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("components/BarBuy.ets(157:11)");
            Row.margin({ bottom: 110 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarBuy.ets(158:13)");
            Column.alignItems(HorizontalAlign.Start);
            Column.backgroundColor('#FFEEEEEE');
            Column.height("100%");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            //swiper
            if (this.hots.length) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Swiper.create();
                        Swiper.debugLine("components/BarBuy.ets(162:17)");
                        Swiper.autoPlay(true);
                        Swiper.interval(3000);
                        Swiper.duration(1000);
                        Swiper.borderRadius(20);
                        Swiper.width(260);
                        Swiper.margin({ left: 5 });
                        if (!isInitialRender) {
                            Swiper.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Image.create(item);
                                Image.debugLine("components/BarBuy.ets(164:21)");
                                Image.width('100%');
                                Image.height(100);
                                if (!isInitialRender) {
                                    Image.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        };
                        this.forEachUpdateFunction(elmtId, this.hots, forEachItemGenFunction);
                        if (!isInitialRender) {
                            ForEach.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    ForEach.pop();
                    Swiper.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("components/BarBuy.ets(174:15)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //右侧菜单
            List.create();
            List.debugLine("components/BarBuy.ets(176:17)");
            //右侧菜单
            List.height('100%');
            //右侧菜单
            List.width('75%');
            if (!isInitialRender) {
                //右侧菜单
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, i) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.backgroundColor(Color.White);
                        ListItem.margin({ top: 8, left: 8, right: 8 });
                        ListItem.borderRadius(10);
                        ListItem.debugLine("components/BarBuy.ets(178:21)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("components/BarBuy.ets(179:23)");
                            __Row__IndexFood();
                            Row.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/Order',
                                    params: {
                                        uid: this.uid,
                                        fid: item.id,
                                        food: item.food,
                                        logo: item.logo,
                                        price: item.price
                                    }
                                });
                            });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.logo);
                            Image.debugLine("components/BarBuy.ets(180:25)");
                            Image.width(70);
                            Image.height(70);
                            Image.margin(10);
                            Image.borderRadius(10);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("components/BarBuy.ets(185:25)");
                            Column.layoutWeight(1);
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.food);
                            Text.debugLine("components/BarBuy.ets(186:27)");
                            Text.margin({ top: 20 });
                            Text.fontWeight(FontWeight.Bold);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.price + '元');
                            Text.debugLine("components/BarBuy.ets(189:27)");
                            Text.fontColor(Color.Gray);
                            Text.margin({ top: 10 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("components/BarBuy.ets(179:23)");
                            __Row__IndexFood();
                            Row.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/Order',
                                    params: {
                                        uid: this.uid,
                                        fid: item.id,
                                        food: item.food,
                                        logo: item.logo,
                                        price: item.price
                                    }
                                });
                            });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.logo);
                            Image.debugLine("components/BarBuy.ets(180:25)");
                            Image.width(70);
                            Image.height(70);
                            Image.margin(10);
                            Image.borderRadius(10);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("components/BarBuy.ets(185:25)");
                            Column.layoutWeight(1);
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.food);
                            Text.debugLine("components/BarBuy.ets(186:27)");
                            Text.margin({ top: 20 });
                            Text.fontWeight(FontWeight.Bold);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.price + '元');
                            Text.debugLine("components/BarBuy.ets(189:27)");
                            Text.fontColor(Color.Gray);
                            Text.margin({ top: 10 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.foods, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        //右侧菜单
        List.pop();
        Column.pop();
        Column.pop();
        Row.pop();
        // List列表是祖孙三代
        Row.pop();
        //这里面可以有多个Column并列
        //Stack层叠组件，里面的组件会产生层叠效果
        Column.pop();
        //垂直容器
        //仅能有一个根组件：Column
        Refresh.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "BarBuy", new BarBuy(undefined, {}));
}
//# sourceMappingURL=BarBuy.js.map