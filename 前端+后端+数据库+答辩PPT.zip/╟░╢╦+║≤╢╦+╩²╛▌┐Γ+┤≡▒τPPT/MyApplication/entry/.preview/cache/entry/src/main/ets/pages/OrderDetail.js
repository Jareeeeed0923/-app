import router from '@ohos:router';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import { VOrder } from '@bundle:com.example.myapplication/entry/ets/model/Bean';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
class OrderDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__vorder = new ObservedPropertyObjectPU(new VOrder(), this, "vorder");
        this.oid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.vorder !== undefined) {
            this.vorder = params.vorder;
        }
        if (params.oid !== undefined) {
            this.oid = params.oid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__vorder.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__vorder.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get vorder() {
        return this.__vorder.get();
    }
    set vorder(newValue) {
        this.__vorder.set(newValue);
    }
    aboutToAppear() {
        this.oid = router.getParams()['oid'];
        console.log(this.oid.toString());
        let http = new Http('/vorder/askById/app?id=' + this.oid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.vorder = resp.vorder[0];
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(26:5)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: '订单详情' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(28:7)");
            Column.width('100%');
            Column.height(168);
            Column.backgroundColor('#ff71ceee');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('订单已完成');
            Text.debugLine("pages/OrderDetail.ets(30:9)");
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(26);
            Text.margin({ top: 20, left: -140 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('订单已完成,祝您用餐愉快');
            Text.debugLine("pages/OrderDetail.ets(35:9)");
            Text.fontColor(Color.White);
            Text.fontSize(17);
            Text.margin({ top: 20, left: -90 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(40:9)");
            Column.margin({ top: 30 });
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F3F5');
            Column.borderRadius(24);
            Column.padding(24);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 领券
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(43:11)");
            // 领券
            Column.alignItems(HorizontalAlign.Start);
            // 领券
            Column.width(336);
            // 领券
            Column.height(140);
            // 领券
            Column.backgroundColor('#FFFFFF');
            // 领券
            Column.borderRadius(24);
            // 领券
            Column.padding(24);
            if (!isInitialRender) {
                // 领券
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(44:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(45:15)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(46:17)");
            Row.margin({ top: 0 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("加店长群领");
            Text.debugLine("pages/OrderDetail.ets(47:19)");
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("30元券包");
            Text.debugLine("pages/OrderDetail.ets(49:19)");
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Red);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("周周领福利");
            Text.debugLine("pages/OrderDetail.ets(53:17)");
            Text.padding({ top: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("识别右方二维码 →");
            Text.debugLine("pages/OrderDetail.ets(55:17)");
            Text.padding(7);
            Text.backgroundColor('#ffdb2424');
            Text.borderRadius(10);
            Text.fontColor(Color.White);
            Text.margin({ top: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/0Q%7D%24%282%25C3%5B4LBGY5P3X6BWA.png");
            Image.debugLine("pages/OrderDetail.ets(64:15)");
            Image.width(100);
            Image.margin({ left: 35 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        // 领券
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 详情1
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(77:11)");
            // 详情1
            Column.alignItems(HorizontalAlign.Start);
            // 详情1
            Column.width(336);
            // 详情1
            Column.height(140);
            // 详情1
            Column.backgroundColor('#FFFFFF');
            // 详情1
            Column.borderRadius(24);
            // 详情1
            Column.padding(24);
            // 详情1
            Column.margin({ top: 15 });
            if (!isInitialRender) {
                // 详情1
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(78:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.vorder.logo);
            Image.debugLine("pages/OrderDetail.ets(79:15)");
            Image.width(100);
            Image.height(100);
            Image.borderRadius(10);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(83:15)");
            Column.margin({ left: 20 });
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.vorder.food);
            Text.debugLine("pages/OrderDetail.ets(84:17)");
            Text.margin({ top: 0 });
            Text.fontSize('20fp');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(87:17)");
            Row.margin({ top: 49, left: 90 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("共" + this.vorder.count + "件");
            Text.debugLine("pages/OrderDetail.ets(88:19)");
            Text.fontColor(Color.Gray);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("￥" + (this.vorder.count * this.vorder.price).toString());
            Text.debugLine("pages/OrderDetail.ets(90:19)");
            Text.fontSize('20fp');
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        Row.pop();
        // 详情1
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 详情2
            Column.create();
            Column.debugLine("pages/OrderDetail.ets(108:11)");
            // 详情2
            Column.alignItems(HorizontalAlign.Start);
            // 详情2
            Column.width(336);
            // 详情2
            Column.height(260);
            // 详情2
            Column.backgroundColor('#FFFFFF');
            // 详情2
            Column.borderRadius(24);
            // 详情2
            Column.padding(24);
            // 详情2
            Column.margin({ top: 15 });
            if (!isInitialRender) {
                // 详情2
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(109:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("下单时间");
            Text.debugLine("pages/OrderDetail.ets(110:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.vorder.ctime);
            Text.debugLine("pages/OrderDetail.ets(111:15)");
            Text.margin({ left: 30 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(115:13)");
            Row.margin({ top: 18 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("订单编号");
            Text.debugLine("pages/OrderDetail.ets(116:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.oid.toString());
            Text.debugLine("pages/OrderDetail.ets(117:15)");
            Text.margin({ left: 30 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(122:13)");
            Row.margin({ top: 18 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("买家姓名");
            Text.debugLine("pages/OrderDetail.ets(123:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.vorder.username);
            Text.debugLine("pages/OrderDetail.ets(124:15)");
            Text.margin({ left: 30 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(129:13)");
            Row.margin({ top: 18 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("手机号");
            Text.debugLine("pages/OrderDetail.ets(130:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.vorder.phone);
            Text.debugLine("pages/OrderDetail.ets(131:15)");
            Text.margin({ left: 30 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/OrderDetail.ets(136:13)");
            Row.margin({ top: 18 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("地址");
            Text.debugLine("pages/OrderDetail.ets(137:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.vorder.address);
            Text.debugLine("pages/OrderDetail.ets(138:15)");
            Text.margin({ left: 30 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        // 详情2
        Column.pop();
        Column.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new OrderDetail(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=OrderDetail.js.map