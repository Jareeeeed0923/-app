import { BarIndex } from '@bundle:com.example.myapplication/entry/ets/components/BarIndex';
import { BarBuy } from '@bundle:com.example.myapplication/entry/ets/components/BarBuy';
import { NavigationList } from '@bundle:com.example.myapplication/entry/ets/model/NavigationList';
import { BarOrder } from '@bundle:com.example.myapplication/entry/ets/components/BarOrder';
import { BarMy } from '@bundle:com.example.myapplication/entry/ets/components/BarMy';
export class MainPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__mCurrentPage = new ObservedPropertySimplePU(0, this, "mCurrentPage");
        this.mTabController = new TabsController();
        this.mTabDataList = NavigationList;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.mCurrentPage !== undefined) {
            this.mCurrentPage = params.mCurrentPage;
        }
        if (params.mTabController !== undefined) {
            this.mTabController = params.mTabController;
        }
        if (params.mTabDataList !== undefined) {
            this.mTabDataList = params.mTabDataList;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__mCurrentPage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__mCurrentPage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get mCurrentPage() {
        return this.__mCurrentPage.get();
    }
    set mCurrentPage(newValue) {
        this.__mCurrentPage.set(newValue);
    }
    getTabIndexByItem(navigationItem) {
        return this.mTabDataList.findIndex(item => item.id === navigationItem.id);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.End, controller: this.mTabController });
            Tabs.debugLine("pages/MainPage.ets(21:5)");
            Tabs.scrollable(true);
            Tabs.vertical(false);
            Tabs.barMode(BarMode.Fixed);
            Tabs.onChange((index) => {
                this.mCurrentPage = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TabContent.create(() => {
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            // 根据NavigationItem动态显示内容
                            // Text(`${item.text} 页面`)
                            if (item.id == 0) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new BarIndex(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            else if (item.id == 1) {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new BarBuy(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            else if (item.id == 2) {
                                this.ifElseBranchUpdateFunction(2, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new BarOrder(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            else if (item.id == 3) {
                                this.ifElseBranchUpdateFunction(3, () => {
                                    {
                                        this.observeComponentCreation((elmtId, isInitialRender) => {
                                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                            if (isInitialRender) {
                                                ViewPU.create(new BarMy(this, {}, undefined, elmtId));
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                            ViewStackProcessor.StopGetAccessRecording();
                                        });
                                    }
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                    });
                    TabContent.tabBar({ builder: () => {
                            this.TabBuilder.call(this, item);
                        } });
                    TabContent.debugLine("pages/MainPage.ets(23:9)");
                    if (!isInitialRender) {
                        TabContent.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.mTabDataList, forEachItemGenFunction, item => item.id.toString(), true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Tabs.pop();
    }
    TabBuilder(item, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MainPage.ets(53:5)");
            Column.justifyContent(FlexAlign.Center);
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.mCurrentPage === this.getTabIndexByItem(item) ? item.icon_selected : item.icon_normal);
            Image.debugLine("pages/MainPage.ets(54:7)");
            Image.width('24vp');
            Image.height('24vp');
            Image.objectFit(ImageFit.Contain);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.text);
            Text.debugLine("pages/MainPage.ets(59:7)");
            Text.fontSize('10fp');
            Text.fontWeight(500);
            Text.margin({ top: '4vp' });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MainPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MainPage.js.map