import router from '@ohos:router';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import { Coupon } from '@bundle:com.example.myapplication/entry/ets/model/Bean';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
import { Util } from '@bundle:com.example.myapplication/entry/ets/model/Util';
class Order extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__food = new ObservedPropertySimplePU('', this, "food");
        this.fid = 0;
        this.uid = 0;
        this.__cid = new ObservedPropertySimplePU(0, this, "cid");
        this.__logo = new ObservedPropertySimplePU('', this, "logo");
        this.__phone = new ObservedPropertySimplePU('', this, "phone");
        this.__count = new ObservedPropertySimplePU('1', this, "count");
        this.__address = new ObservedPropertySimplePU('', this, "address");
        this.__price = new ObservedPropertySimplePU(0, this, "price");
        this.__totOfCoupon = new ObservedPropertySimplePU(0, this, "totOfCoupon");
        this.__coupon = new ObservedPropertyObjectPU(new Coupon(), this, "coupon");
        this.__couponName = new ObservedPropertySimplePU('', this, "couponName");
        this.__couponValue = new ObservedPropertySimplePU('0', this, "couponValue");
        this.__spend = new ObservedPropertySimplePU(0, this, "spend");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.food !== undefined) {
            this.food = params.food;
        }
        if (params.fid !== undefined) {
            this.fid = params.fid;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
        if (params.cid !== undefined) {
            this.cid = params.cid;
        }
        if (params.logo !== undefined) {
            this.logo = params.logo;
        }
        if (params.phone !== undefined) {
            this.phone = params.phone;
        }
        if (params.count !== undefined) {
            this.count = params.count;
        }
        if (params.address !== undefined) {
            this.address = params.address;
        }
        if (params.price !== undefined) {
            this.price = params.price;
        }
        if (params.totOfCoupon !== undefined) {
            this.totOfCoupon = params.totOfCoupon;
        }
        if (params.coupon !== undefined) {
            this.coupon = params.coupon;
        }
        if (params.couponName !== undefined) {
            this.couponName = params.couponName;
        }
        if (params.couponValue !== undefined) {
            this.couponValue = params.couponValue;
        }
        if (params.spend !== undefined) {
            this.spend = params.spend;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__food.purgeDependencyOnElmtId(rmElmtId);
        this.__cid.purgeDependencyOnElmtId(rmElmtId);
        this.__logo.purgeDependencyOnElmtId(rmElmtId);
        this.__phone.purgeDependencyOnElmtId(rmElmtId);
        this.__count.purgeDependencyOnElmtId(rmElmtId);
        this.__address.purgeDependencyOnElmtId(rmElmtId);
        this.__price.purgeDependencyOnElmtId(rmElmtId);
        this.__totOfCoupon.purgeDependencyOnElmtId(rmElmtId);
        this.__coupon.purgeDependencyOnElmtId(rmElmtId);
        this.__couponName.purgeDependencyOnElmtId(rmElmtId);
        this.__couponValue.purgeDependencyOnElmtId(rmElmtId);
        this.__spend.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__food.aboutToBeDeleted();
        this.__cid.aboutToBeDeleted();
        this.__logo.aboutToBeDeleted();
        this.__phone.aboutToBeDeleted();
        this.__count.aboutToBeDeleted();
        this.__address.aboutToBeDeleted();
        this.__price.aboutToBeDeleted();
        this.__totOfCoupon.aboutToBeDeleted();
        this.__coupon.aboutToBeDeleted();
        this.__couponName.aboutToBeDeleted();
        this.__couponValue.aboutToBeDeleted();
        this.__spend.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get food() {
        return this.__food.get();
    }
    set food(newValue) {
        this.__food.set(newValue);
    }
    get cid() {
        return this.__cid.get();
    }
    set cid(newValue) {
        this.__cid.set(newValue);
    }
    get logo() {
        return this.__logo.get();
    }
    set logo(newValue) {
        this.__logo.set(newValue);
    }
    get phone() {
        return this.__phone.get();
    }
    set phone(newValue) {
        this.__phone.set(newValue);
    }
    get count() {
        return this.__count.get();
    }
    set count(newValue) {
        this.__count.set(newValue);
    }
    get address() {
        return this.__address.get();
    }
    set address(newValue) {
        this.__address.set(newValue);
    }
    get price() {
        return this.__price.get();
    }
    set price(newValue) {
        this.__price.set(newValue);
    }
    get totOfCoupon() {
        return this.__totOfCoupon.get();
    }
    set totOfCoupon(newValue) {
        this.__totOfCoupon.set(newValue);
    }
    get coupon() {
        return this.__coupon.get();
    }
    set coupon(newValue) {
        this.__coupon.set(newValue);
    }
    get couponName() {
        return this.__couponName.get();
    }
    set couponName(newValue) {
        this.__couponName.set(newValue);
    }
    get couponValue() {
        return this.__couponValue.get();
    }
    set couponValue(newValue) {
        this.__couponValue.set(newValue);
    }
    get spend() {
        return this.__spend.get();
    }
    set spend(newValue) {
        this.__spend.set(newValue);
    }
    onPageShow() {
        var _a;
        this.cid = (_a = router.getParams()) === null || _a === void 0 ? void 0 : _a['cid'];
        if (!this.cid) {
            this.cid = 0;
        }
        else {
            this.askCouponById();
        }
    }
    aboutToAppear() {
        let params = router.getParams();
        this.food = params['food'];
        this.fid = params['fid'];
        this.uid = params['uid'];
        this.logo = params['logo'];
        this.price = params['price'];
        this.spend = this.price * parseInt(this.count);
        let http = new Http('/coupon/getNumById/app?uid=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.totOfCoupon = resp.tot[0].x;
        });
    }
    askCouponById() {
        let http = new Http('/coupon/getById/app?id=' + this.cid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.coupon = resp.coupon[0];
            this.couponName = resp.coupon[0].name;
            this.couponValue = resp.coupon[0].value.toString();
            this.spend = Math.max(0, this.price * parseInt(this.count) - resp.coupon[0].value);
        });
    }
    toCouponUse() {
        router.pushUrl({
            url: 'pages/MyCouponUse',
            params: {
                uid: this.uid,
            }
        });
    }
    useCoupon() {
        let http = new Http('/coupon/useCoupon/app?id=' + this.cid);
        http.get().then((resp) => {
            resp = http.parse(resp);
        });
    }
    goCoupon() {
        let http = new Http('/coupon/gotCoupon/app?uid=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
        });
    }
    submitOrder() {
        let http = new Http('/order/add/app');
        http.get({
            uid: this.uid,
            fid: this.fid,
            count: this.count,
            address: this.address,
            phone: this.phone
        }).then((resp) => {
            resp = http.parse(resp);
            if (resp == 1) {
                Util.alert('订单提交成功');
                setTimeout(() => {
                    router.back();
                }, 1000);
            }
            else {
                Util.alert(resp);
            }
        });
    }
    addPoint() {
        let http = new Http('/user/addPoint/app');
        http.get({
            uid: this.uid,
            value: this.price * parseInt(this.count)
        }).then((resp) => {
            resp = http.parse(resp);
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(128:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: '提交订单' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(130:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.logo);
            Image.debugLine("pages/Order.ets(131:9)");
            Image.width(100);
            Image.height(100);
            Image.borderRadius(10);
            Image.margin({ top: 20, bottom: 30 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.food);
            Text.debugLine("pages/Order.ets(136:9)");
            Text.fontSize(20);
            Text.margin({ top: -80, left: 14 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(140:9)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("￥" + this.price.toString());
            Text.debugLine("pages/Order.ets(142:11)");
            Text.margin({ left: 80, top: -10, bottom: 10 });
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(147:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E5%87%8F%E5%8F%B7.png");
            Image.debugLine("pages/Order.ets(148:13)");
            Image.width(36);
            Image.onClick(() => {
                if (parseInt(this.count) >= 2) {
                    this.count = (parseInt(this.count) - 1).toString();
                }
                if (this.cid) {
                    this.spend = Math.max(0, this.price * parseInt(this.count) - parseInt(this.couponValue));
                }
                else {
                    this.spend = this.price * parseInt(this.count);
                }
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ text: this.count });
            TextInput.debugLine("pages/Order.ets(161:13)");
            TextInput.type(InputType.Number);
            TextInput.maxLength(3);
            TextInput.margin(10);
            TextInput.fontSize(20);
            TextInput.placeholderFont({ size: 20 });
            TextInput.onChange(e => {
                this.count = e;
                if (!this.count) {
                    this.count = '0';
                }
                if (this.cid) {
                    this.spend = Math.max(0, this.price * parseInt(this.count) - parseInt(this.couponValue));
                }
                else {
                    this.spend = this.price * parseInt(this.count);
                }
            });
            TextInput.width(50);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE27.png");
            Image.debugLine("pages/Order.ets(180:13)");
            Image.width(50);
            Image.onClick(() => {
                this.count = (parseInt(this.count) + 1).toString();
                if (this.cid) {
                    this.spend = Math.max(0, this.price * parseInt(this.count) - parseInt(this.couponValue));
                }
                else {
                    this.spend = this.price * parseInt(this.count);
                }
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(196:7)");
            Column.width("95%");
            Column.height(220);
            Column.borderRadius(10);
            Column.backgroundColor("#EEEEEF");
            Column.padding(5);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(197:9)");
            Column.backgroundColor('#fffcd9c2');
            Column.width("99%");
            Column.height(50);
            Column.borderRadius(10);
            Column.margin({ bottom: 10, top: 5 });
            Column.onClick(() => {
                this.toCouponUse();
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(198:11)");
            Row.margin({ top: 3 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create("https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png");
            Image.debugLine("pages/Order.ets(199:13)");
            Image.width(40);
            Image.margin({ right: 4 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("红包/优惠券");
            Text.debugLine("pages/Order.ets(202:13)");
            Text.fontSize(16);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.cid == 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(this.totOfCoupon + "张可用 >");
                        Text.debugLine("pages/Order.ets(205:15)");
                        Text.margin({ left: 100 });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(this.couponName);
                        Text.debugLine("pages/Order.ets(209:15)");
                        Text.margin({ left: 100 });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(224:9)");
            Column.backgroundColor('#fff2fcff');
            Column.width("98%");
            Column.borderRadius(10);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(225:11)");
            Row.padding({ top: 8, left: 5, right: 5 });
            Row.margin({ left: 4 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("电话");
            Text.debugLine("pages/Order.ets(226:13)");
            Text.fontSize(18);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '请输入电话', text: '18596231305' });
            TextInput.debugLine("pages/Order.ets(228:13)");
            TextInput.margin({ left: 20, right: 30 });
            TextInput.width(250);
            TextInput.fontSize(20);
            TextInput.borderRadius(10);
            TextInput.placeholderFont({ size: 20 });
            TextInput.onChange(e => this.phone = e);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(238:11)");
            Row.padding({ bottom: 8, left: 5, right: 5 });
            Row.margin({ left: 4 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("地址");
            Text.debugLine("pages/Order.ets(239:13)");
            Text.margin({ top: 10 });
            Text.fontSize(18);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '请输入地址', text: '青岛科技大学崂山校区' });
            TextInput.debugLine("pages/Order.ets(242:13)");
            TextInput.margin({ top: 10, left: 20, right: 30 });
            TextInput.width(250);
            TextInput.fontSize(20);
            TextInput.placeholderFont({ size: 20 });
            TextInput.borderRadius(10);
            TextInput.onChange(e => this.address = e);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(255:9)");
            Row.margin({ left: 140, top: 14 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("优惠");
            Text.debugLine("pages/Order.ets(256:11)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (parseInt(this.couponValue) > (this.price * parseInt(this.count))) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("￥" + this.price * parseInt(this.count));
                        Text.debugLine("pages/Order.ets(259:13)");
                        Text.fontColor('#ffec7636');
                        Text.fontSize(20);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create("￥" + this.couponValue);
                        Text.debugLine("pages/Order.ets(264:13)");
                        Text.fontColor('#ffec7636');
                        Text.fontSize(20);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("小计");
            Text.debugLine("pages/Order.ets(268:11)");
            Text.fontSize(20);
            Text.margin({ left: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("￥" + this.spend.toString());
            Text.debugLine("pages/Order.ets(271:11)");
            Text.fontColor('#ffec7636');
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(285:7)");
            Column.margin({ top: 260 });
            Column.backgroundColor('#ffecebeb');
            Column.width("100%");
            Column.height(100);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(287:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Order.ets(289:11)");
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(291:13)");
            Row.margin({ top: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("合计");
            Text.debugLine("pages/Order.ets(292:15)");
            Text.fontColor('#ffec7636');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("￥");
            Text.debugLine("pages/Order.ets(294:15)");
            Text.fontColor('#ffec7636');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.spend.toString());
            Text.debugLine("pages/Order.ets(296:15)");
            Text.fontSize(28);
            Text.fontColor('#ffec7636');
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Order.ets(302:13)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("共");
            Text.debugLine("pages/Order.ets(303:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.count);
            Text.debugLine("pages/Order.ets(304:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("件");
            Text.debugLine("pages/Order.ets(305:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("已优惠￥");
            Text.debugLine("pages/Order.ets(307:15)");
            Text.margin({ left: 14 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(parseInt(this.couponValue) > (this.price * parseInt(this.count)) ? this.price.toString() : this.couponValue);
            Text.debugLine("pages/Order.ets(309:15)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('提交订单');
            Button.debugLine("pages/Order.ets(314:11)");
            Button.width('50%');
            Button.height(50);
            Button.margin({ top: 18, left: 12 });
            Button.onClick(() => {
                this.submitOrder();
                if (this.cid) {
                    this.useCoupon();
                }
                if (this.price * parseInt(this.count) >= 50) {
                    this.goCoupon();
                }
                this.addPoint();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Order(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Order.js.map