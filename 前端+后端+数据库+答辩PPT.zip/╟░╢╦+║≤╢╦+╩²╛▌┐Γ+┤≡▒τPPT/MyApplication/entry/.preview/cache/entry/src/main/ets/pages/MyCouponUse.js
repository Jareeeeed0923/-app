import router from '@ohos:router';
import { TitleBar } from '@bundle:com.example.myapplication/entry/ets/components/TitleBar';
import { Http } from '@bundle:com.example.myapplication/entry/ets/model/Http';
class MyCoupon extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__coupon = new ObservedPropertyObjectPU([], this, "coupon");
        this.__couponId = new ObservedPropertySimplePU('0', this, "couponId");
        this.uid = 0;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.coupon !== undefined) {
            this.coupon = params.coupon;
        }
        if (params.couponId !== undefined) {
            this.couponId = params.couponId;
        }
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__coupon.purgeDependencyOnElmtId(rmElmtId);
        this.__couponId.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__coupon.aboutToBeDeleted();
        this.__couponId.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get coupon() {
        return this.__coupon.get();
    }
    set coupon(newValue) {
        this.__coupon.set(newValue);
    }
    get couponId() {
        return this.__couponId.get();
    }
    set couponId(newValue) {
        this.__couponId.set(newValue);
    }
    aboutToAppear() {
        this.uid = router.getParams()['uid'];
        let http = new Http('/coupon/getByUid/app?uid=' + this.uid);
        http.get().then((resp) => {
            resp = http.parse(resp);
            this.coupon = resp.coupon;
        });
    }
    // getSelectedImage(index: number): string {
    //   if (this.couponId === index) {
    //     return 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E7%9C%9F%E9%80%89%E4%B8%AD.png';
    //   } else {
    //     return 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E9%80%89%E4%B8%AD.png';
    //   }
    // }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MyCouponUse.ets(34:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TitleBar(this, { title: '我的优惠券' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MyCouponUse.ets(39:7)");
            Column.backgroundColor('#ffeaeaea');
            Column.height('100%');
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/MyCouponUse.ets(40:9)");
            Row.margin({ bottom: 70 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/MyCouponUse.ets(41:11)");
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, i) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.onClick(() => {
                            if (item.id == this.couponId) {
                                this.couponId = '0';
                            }
                            else {
                                this.couponId = item.id.toString();
                            }
                            setTimeout(() => {
                                router.back({
                                    url: 'pages/Order',
                                    params: {
                                        cid: this.couponId
                                    }
                                });
                            }, 1000);
                        });
                        ListItem.debugLine("pages/MyCouponUse.ets(43:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/MyCouponUse.ets(44:17)");
                            Column.height(90);
                            Column.backgroundColor(Color.White);
                            Column.width('95%');
                            Column.borderRadius(10);
                            Column.margin({ left: 8, top: 10 });
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/MyCouponUse.ets(45:19)");
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
                            Image.debugLine("pages/MyCouponUse.ets(46:21)");
                            Image.width(90);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/MyCouponUse.ets(48:21)");
                            Column.margin({ left: 80 });
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.name);
                            Text.debugLine("pages/MyCouponUse.ets(49:23)");
                            Text.fontSize(20);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create("价值:￥" + item.value.toString());
                            Text.debugLine("pages/MyCouponUse.ets(51:23)");
                            Text.margin({ top: 6 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.id.toString() == this.couponId ? 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E7%9C%9F%E9%80%89%E4%B8%AD.png' : 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E9%80%89%E4%B8%AD.png');
                            Image.debugLine("pages/MyCouponUse.ets(57:21)");
                            Image.width(40);
                            Image.margin({ left: 10 });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/MyCouponUse.ets(44:17)");
                            Column.height(90);
                            Column.backgroundColor(Color.White);
                            Column.width('95%');
                            Column.borderRadius(10);
                            Column.margin({ left: 8, top: 10 });
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/MyCouponUse.ets(45:19)");
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create('https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E4%BF%83%E9%94%80%E6%B4%BB%E5%8A%A8-%E4%BC%98%E6%83%A0%E5%88%B8.png');
                            Image.debugLine("pages/MyCouponUse.ets(46:21)");
                            Image.width(90);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("pages/MyCouponUse.ets(48:21)");
                            Column.margin({ left: 80 });
                            Column.alignItems(HorizontalAlign.Start);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.name);
                            Text.debugLine("pages/MyCouponUse.ets(49:23)");
                            Text.fontSize(20);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create("价值:￥" + item.value.toString());
                            Text.debugLine("pages/MyCouponUse.ets(51:23)");
                            Text.margin({ top: 6 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.id.toString() == this.couponId ? 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E7%9C%9F%E9%80%89%E4%B8%AD.png' : 'https://zjsfactory.oss-cn-beijing.aliyuncs.com/%E6%8C%89%E9%92%AE_%E9%80%89%E4%B8%AD.png');
                            Image.debugLine("pages/MyCouponUse.ets(57:21)");
                            Image.width(40);
                            Image.margin({ left: 10 });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.coupon, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MyCoupon(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MyCouponUse.js.map